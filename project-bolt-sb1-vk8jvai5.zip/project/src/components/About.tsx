import React from 'react';
import { CheckCircle } from 'lucide-react';

const features = [
  'Over 20 years of industry experience',
  'Award-winning designs and builds',
  'Fully licensed and insured team',
  'Sustainable building practices',
  'Transparent pricing and timelines',
  'Dedicated project managers',
];

const About = () => {
  return (
    <div id="about" className="bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 sm:gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-2">
          <div className="lg:pr-8 lg:pt-4">
            <div className="lg:max-w-lg">
              <h2 className="text-base font-semibold leading-7 text-blue-600">About Us</h2>
              <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
                Building Excellence Since 2000
              </p>
              <p className="mt-6 text-lg leading-8 text-gray-600">
                We're a team of passionate designers, architects, and builders committed to creating
                exceptional spaces that exceed our clients' expectations.
              </p>
              <dl className="mt-10 max-w-xl space-y-8 text-base leading-7 text-gray-600 lg:max-w-none">
                {features.map((feature) => (
                  <div key={feature} className="relative pl-9">
                    <dt className="inline font-semibold text-gray-900">
                      <CheckCircle className="absolute left-1 top-1 h-5 w-5 text-blue-600" aria-hidden="true" />
                    </dt>
                    <dd className="inline">{feature}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
          <img
            src="https://images.unsplash.com/photo-1556761175-b413da4baf72"
            alt="Team meeting"
            className="w-[48rem] max-w-none rounded-xl shadow-xl ring-1 ring-gray-400/10 sm:w-[57rem] md:-ml-4 lg:-ml-0"
          />
        </div>
      </div>
    </div>
  );
};

export default About;