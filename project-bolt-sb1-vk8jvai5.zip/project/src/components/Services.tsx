import React from 'react';
import { Pencil, Building2, Hammer, PaintBucket } from 'lucide-react';

const services = [
  {
    title: 'Design & Planning',
    description: 'From initial concept to detailed plans, we create designs that match your vision and requirements.',
    icon: Pencil,
  },
  {
    title: 'Construction',
    description: 'Expert construction services delivering quality builds on time and within budget.',
    icon: Building2,
  },
  {
    title: 'Renovation',
    description: 'Transform your existing space with our comprehensive renovation services.',
    icon: Hammer,
  },
  {
    title: 'Interior Finishing',
    description: 'Complete your space with our professional interior finishing services.',
    icon: PaintBucket,
  },
];

const Services = () => {
  return (
    <div id="services" className="py-24 bg-white sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:text-center">
          <h2 className="text-base font-semibold leading-7 text-blue-600">Our Services</h2>
          <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Everything you need to build your perfect space
          </p>
          <p className="mt-6 text-lg leading-8 text-gray-600">
            We offer comprehensive design and build services to bring your project from concept to completion.
          </p>
        </div>
        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
          <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-4">
            {services.map((service) => (
              <div key={service.title} className="flex flex-col">
                <dt className="flex items-center gap-x-3 text-base font-semibold leading-7 text-gray-900">
                  <service.icon className="h-5 w-5 flex-none text-blue-600" aria-hidden="true" />
                  {service.title}
                </dt>
                <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-gray-600">
                  <p className="flex-auto">{service.description}</p>
                </dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
};

export default Services;